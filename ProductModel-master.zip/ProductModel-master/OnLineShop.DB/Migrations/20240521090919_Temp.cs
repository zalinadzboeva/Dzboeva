﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace OnLineShop.DB.Migrations
{
    public partial class Temp : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
